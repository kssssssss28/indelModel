import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { httpService } from './httpService';
import { checkFormatName, spliceFile } from './utils';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ex';
  httpService:httpService
  submitPic = async (e:any)=>{
    const file = e.target.files[0];
    const valid = await checkFormatName(file)
    console.log(valid)
    if(valid){
      spliceFile(file)
    }
    //this.httpService.sendRequest("")

  }
  constructor(httpService:httpService, private http: HttpClient){
    this.httpService = httpService
  }
}
