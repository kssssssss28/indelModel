import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
@Injectable()

export class httpService{
  sendRequest = (data:any)=>{
    this.http.post("http://localhost:3000/",data).subscribe(res=>{
      console.log(res)
    })
  }
  constructor(private http: HttpClient){
    this.http = http
  }
}
