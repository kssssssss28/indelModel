const http = require('http');

const server = http.createServer((req, res) => {
  // 允许跨域请求的域名，可以根据需要进行更改
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'POST') {
    let body = '';
    console.log("req from client")
    
    req.on('data', (chunk) => {
      body += chunk;
    });
    
    req.on('end', () => {
      // 在这里处理请求体的数据
      console.log('POST body:', body);
      
      res.statusCode = 200;
      res.setHeader('Content-Type', 'text/plain');
      res.end('Hello, World!\n');
    });
  } else {
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    res.end('Hello, World!\n');
  }
});

server.listen(3000, 'localhost', () => {
  console.log('Server running at http://localhost:3000/');
});
